//
//  LocationModel.m
//  TestMap
//
//  Created by houzhijie on 2019/4/30.
//  Copyright © 2019 mac. All rights reserved.
//

#import "LocationModel.h"

@implementation LocationModel




@end
