//
//  SaveLocationTool.h
//  LocationTest
//
//  Created by houzhijie on 2019/4/24.
//  Copyright © 2019 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JQFMDB.h"

NS_ASSUME_NONNULL_BEGIN

@interface SaveLocationTool : NSObject

+ (instancetype)shareLocationTool;

#pragma mark ----------------------- 数据库
/**
 查看所有的数据
 
 @param tableName 要查看的表的名字
 @return 返回
 */
-(NSArray *)lookDataTableName:(NSString *)tableName;

/**
 查看具体一条数据
 
 @param tableName 要查看的表的名字
 @param format 条件 写法 "where 属性 = '%@'" 如 "where vid = '%@'"
 @return 返回 modle 或者是nil
 */
-(id)lookDataModelWithTableName:(NSString *)tableName
                         format:(NSString *)format;

/**
 查看数据是否存在
 
 @param tableName 表名字
 @param format 条件 写法 "where 属性 = '%@'" 如 "where vid = '%@'"
 @return 返回结果 yes 存在 NO 不存在
 */
-(BOOL)isExistTableName:(NSString *)tableName
                 format:(NSString *)format;


/**
 查询表是否存在

 @param tableName tableName 表名字
 @return 返回结果
 */
-(BOOL)isExistTable:(NSString *)tableName;


/**
 删除表中的数据
 
 @param tableName 表名字
 @param format 条件 写法 "where 属性 = '%@'" 如 "where vid = '%@'"
 */
-(BOOL)deleteDataTableName:(NSString *)tableName
                    format:(NSString *)format;

/**
 更改数据
 
 @param tableName 表名
 @param model model
 @param format 条件 写法 "where 属性 = '%@'" 如 "where vid = '%@'"
 */
-(void)updateDataWithTableName:(NSString *)tableName
                         model:(id)model
                        format:(NSString *)format;
/**
 存储数据
 
 @param tableName 表名
 @param historyModel model
 */
-(void)saveDataTableName:(NSString *)tableName
            historyModel:(id)historyModel;

/**
 删除表
 
 @param tableName 表名
 @return 返回删除结果 yes 为成功 no 为失败
 */
-(BOOL)deleteTableName:(NSString *)tableName;

/**
 查询表中最后一条数据
 
 @param tableName 表名
 @return return value description
 */
- (id)lastDataWithTableName:(NSString *)tableName;
@end

NS_ASSUME_NONNULL_END
