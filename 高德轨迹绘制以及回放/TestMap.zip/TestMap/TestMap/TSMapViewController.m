//
//  TSMapViewController.m
//  TestMap
//
//  Created by mac on 2019/3/27.
//  Copyright © 2019 mac. All rights reserved.
//

#import "TSMapViewController.h"
#import <MAMapKit/MAMapKit.h>
#import <AMapFoundationKit/AMapFoundationKit.h>
#import "TSPolylineManager.h"

#define RgbaColor(r, g, b, a)   [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:(a)]

@interface TSMapViewController ()<MAMapViewDelegate>

@property (nonatomic , strong)MAMapView *mapView;//地图
// 用户位置设置
@property (nonatomic , strong)MAUserLocationRepresentation *userLocation;

@property (nonatomic,strong)UIButton * repalyButton;

@property (nonatomic, strong)NSMutableArray *arrayColors;

@end

@implementation TSMapViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.mapView];
    
    
    // 获取每段颜色
    [TSPolylineManager fetchColors:self.arrayLoca block:^(NSArray *arrayColors, NSArray *indexs) {
        // 创建多段折线
//        [TSPolylineManager polyLine:self.mapView locaPointArray:self.arrayLoca arrayIndex:indexs];
        [self.arrayColors addObjectsFromArray:arrayColors];
        [TSPolylineManager overPlay:self.mapView locaPointArray:self.arrayLoca arrayIndex:indexs];
        
    }];
    
    
    
    [self.view addSubview:self.repalyButton];
}

#pragma mark --- mapViewDelegate
- (MAAnnotationView *)mapView:(MAMapView *)mapView viewForAnnotation:(id <MAAnnotation>)annotation {
    if ([[TSPolylineManager shareManager].playAnnotation isEqual:annotation]) {
        // 创建轨迹回放的移动箭头
        static NSString *pointReuseIndetifier = @"myReuseIndetifier";
        MAAnnotationView *annotationView = (MAAnnotationView *)[self.mapView dequeueReusableAnnotationViewWithIdentifier:pointReuseIndetifier];
        if (annotationView == nil){
            annotationView = [[MAAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:pointReuseIndetifier];
            UIImage *imge  =  ImageNamed(@"userPosition.png");
            annotationView.image =  imge;
            annotationView.draggable = NO;
        }
        
        return annotationView;
    }
    
    return nil;
}

- (MAOverlayRenderer *)mapView:(MAMapView *)mapView rendererForOverlay:(id <MAOverlay>)overlay
{
    if ([overlay isKindOfClass:[MAMultiPolyline class]]) {
        if ([overlay isEqual:[TSPolylineManager shareManager].texturePolyline]) {
            
            MAMultiTexturePolylineRenderer *polylineRenderer = [[MAMultiTexturePolylineRenderer alloc] initWithMultiPolyline:overlay];

            polylineRenderer.lineWidth = 38.f;
            polylineRenderer.strokeTextureImages = @[[UIImage imageNamed:@"custtexture"]];
            return polylineRenderer;
        }
        else {
            
            // 多色轨迹
            MAMultiColoredPolylineRenderer * polylineRenderer = [[MAMultiColoredPolylineRenderer alloc] initWithMultiPolyline:overlay];
            
            polylineRenderer.lineWidth = 12.f;
            polylineRenderer.strokeColors = self.arrayColors;
            polylineRenderer.gradient = NO;
            return polylineRenderer;
        }

    }
    if ([overlay isKindOfClass:[MATraceReplayOverlay class]])
    {
        MATraceReplayOverlayRenderer *ret = [[MATraceReplayOverlayRenderer alloc] initWithOverlay:overlay];
        ret.lineWidth = 8;
        ret.strokeColors = @[UIColor.clearColor,UIColor.clearColor];
        ret.lineJoinType = kMALineJoinRound;
        ret.lineCapType  = kMALineCapRound;
        
        
        ret.strokeImage = [UIImage imageNamed:@"custtexture"];
        ret.carImage = [UIImage imageNamed:@"bnavi_icon_location_fixed"];
        [TSPolylineManager shareManager].overlayRenderer = ret;
        return ret;
    }
    return nil;
}

#pragma mark -- btnClick

- (void)btnClick:(UIButton *)btn {
    btn.selected = !btn.selected;
    
    if (btn.selected) {
        [[TSPolylineManager shareManager] startAnimation];
    }
    else {
        [[TSPolylineManager shareManager] stopAnimation];
    }
}

#pragma mark -- 懒加载

- (NSMutableArray *)arrayColors {
    if (!_arrayColors) {
        _arrayColors = [NSMutableArray array];
    }
    return _arrayColors;
}

- (UIButton *)repalyButton {
    if (!_repalyButton) {
        _repalyButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _repalyButton.frame = CGRectMake(30, 70, 40, 40);
        [_repalyButton setTitle:@"回放" forState:(UIControlStateNormal)];
        [_repalyButton setTitle:@"暂停" forState:(UIControlStateSelected)];
        [_repalyButton setTitleColor:UIColor.grayColor forState:(UIControlStateNormal)];
        [_repalyButton setBackgroundColor:UIColor.whiteColor];
        [_repalyButton addTarget:self action:@selector(btnClick:) forControlEvents:(UIControlEventTouchUpInside)];
        _repalyButton.layer.cornerRadius = 2;
        _repalyButton.layer.shadowOffset = CGSizeMake(0, 1);
        _repalyButton.layer.shadowColor = RgbaColor(0, 0, 0, 0.22).CGColor;
        _repalyButton.layer.shadowRadius = 3;
        _repalyButton.layer.shadowOpacity = 0.8;
        _repalyButton.selected = NO;
    }
    return _repalyButton;
}

- (MAMapView *)mapView {
    if (!_mapView) {
        _mapView = [[MAMapView alloc]initWithFrame:CGRectMake(0, 64, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height - 64)];
        ///如果您需要进入地图就显示定位小蓝点，则需要下面两行代码
//        _mapView.showsUserLocation = YES;
//        _mapView.userTrackingMode = MAUserTrackingModeFollow;
        
//        _mapView.logoCenter = CGPointMake(CGRectGetWidth(self.view.bounds)-55, 450);// 地图logo位置
        _mapView.showsCompass= YES; // 设置成NO表示关闭指南针；YES表示显示指南针
        _mapView.zoomLevel = 13;
        _mapView.delegate = self;
//        _mapView.compassOrigin= CGPointMake(_mapView.compassOrigin.x, 22); //设置指南针位置
        [_mapView updateUserLocationRepresentation:self.userLocation];
    }
    return _mapView;
}

- (MAUserLocationRepresentation *)userLocation {
    if (!_userLocation) {
        _userLocation = [[MAUserLocationRepresentation alloc]init];
        
        _userLocation.showsAccuracyRing = YES; //显示精度圈 默认yes
        _userLocation.showsHeadingIndicator = YES; // 显示方向指示 默认为yes
        
        _userLocation.strokeColor = UIColor.grayColor; // 精度圈 边线颜色
        
        _userLocation.lineWidth = 2; //精度圈 边线宽度 默认0
//        _userLocation.enablePulseAnnimation = YES;
        _userLocation.fillColor = UIColor.grayColor;
        _userLocation.image = [UIImage imageNamed:@"bnavi_icon_location_fixed"];
    }
    return _userLocation;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
