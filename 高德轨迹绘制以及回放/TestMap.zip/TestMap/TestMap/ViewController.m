//
//  ViewController.m
//  TestMap
//
//  Created by mac on 2019/3/27.
//  Copyright © 2019 mac. All rights reserved.
//

#import "ViewController.h"
#import "TSMapViewController.h"
#import "TSHttpTool.h"
#import "TSTrackInfoVM.h"
#import "TSLocaModel.h"
#import <AMapFoundationKit/AMapFoundationKit.h>

#import "SaveLocationTool.h"

#import "LocationModel.h"
#import "TSLocaModel.h"



@interface ViewController ()

@property (nonatomic,strong)NSMutableArray * arrayData;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self requseResult];
}

/**
 数据请求
 */
- (void)requseResult {
//    [TSTrackInfoVM requestTrackInfo:^(id dic) {
//        NSArray * arrayModel = (NSArray *)dic;
//        NSLog(@"%@",arrayModel);
//        [self.arrayData removeAllObjects];
//        [self.arrayData addObjectsFromArray:arrayModel];
//
//    }];
//    [self loadLocalData];
    [self loadLocalDatabase];
}

- (void)loadLocalDatabase {
    [self.arrayData removeAllObjects];
    // 获取文件路径
    
    NSArray * array = [[SaveLocationTool shareLocationTool] lookDataTableName:@"LocationModel"];
    for (LocationModel * model in array) {
        CLLocationCoordinate2D amap = AMapCoordinateConvert(CLLocationCoordinate2DMake([model.lat doubleValue],[model.lon doubleValue]), AMapCoordinateTypeBaidu);
        TSLocaModel *tsModel = [TSLocaModel new];
        tsModel.latitude = [NSString stringWithFormat:@"%f",amap.latitude];
        tsModel.longitude = [NSString stringWithFormat:@"%f",amap.longitude];
        [self.arrayData addObject:tsModel];
    }
    NSLog(@"%@",self.arrayData);
}

- (void)loadLocalData {
    [self.arrayData removeAllObjects];
    // 获取文件路径
    NSString *path = [[NSBundle mainBundle] pathForResource:@"test" ofType:@"json"];
    // 将文件数据化
    NSData *data = [[NSData alloc] initWithContentsOfFile:path];
    // 对数据进行JSON格式化并返回字典形式
    NSDictionary * dicTest = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
    NSArray * array = [dicTest objectForKey:@"data"];
    
    for (NSDictionary * dic in array) {
        TSLocaModel * model = [[TSLocaModel alloc]init];
        CLLocationCoordinate2D amap = AMapCoordinateConvert(CLLocationCoordinate2DMake([[dic objectForKey:@"lat"] doubleValue],[[dic objectForKey:@"lon"] doubleValue]), AMapCoordinateTypeBaidu);
        model.latitude = [NSString stringWithFormat:@"%f",amap.latitude];//[dic objectForKey:@"lat"];//
        model.longitude = [NSString stringWithFormat:@"%f",amap.longitude];//[dic objectForKey:@"lon"];//
        [self.arrayData addObject:model];
    }
}

- (NSMutableArray *)arrayData {
    if (!_arrayData) {
        _arrayData = [NSMutableArray array];
    }
    return _arrayData;
}

- (void) touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if (self.arrayData.count != 0) {
        TSMapViewController *vc = [TSMapViewController new];
        vc.arrayLoca = self.arrayData;
        [self.navigationController pushViewController:vc animated:YES];
    }
}

@end
