//
//  TSTrackInfoVM.m
//  TestMap
//
//  Created by mac on 2019/3/28.
//  Copyright © 2019 mac. All rights reserved.
//

#import "TSTrackInfoVM.h"
#import "TSLocaModel.h"
#import <MJExtension/MJExtension.h>
#import <AMapFoundationKit/AMapFoundationKit.h>

#define GetObjectFromDicWithKey(dictonary, key , Class) [[dictonary objectForKey:key] isKindOfClass:[Class class]] ? [dictonary objectForKey:key] : nil


@implementation TSTrackInfoVM

/**
 请求快递员轨迹

 @param finish finish description
 */
+ (void)requestTrackInfo:(requestBackData)finish {
    [[TSHttpTool shareHttpTool] getActionFinishedBlock:^(id dic) {
        NSDictionary * diction = (NSDictionary *)dic;
        NSDictionary * dicData = [diction objectForKey:@"data"];
        NSArray * arrayDic = GetObjectFromDicWithKey(dicData, @"trackList", NSArray);
        
        NSArray * arrayModel = [TSLocaModel mj_objectArrayWithKeyValuesArray:[self conversionTime:arrayDic]];
        if (finish) {
            finish(arrayModel);
        }
    }];
}


/**
 对数据进行处理

 @param arrayData 数据数组
 @return 返回处理完的数据数组
 */
+ (NSArray *)conversionTime:(NSArray *)arrayData {
    NSMutableArray * arrayMU = [NSMutableArray array];
    @autoreleasepool {
        
        for (NSDictionary * dicData in arrayData) {
            
            NSMutableDictionary * dicMU = [[NSMutableDictionary alloc]initWithDictionary:dicData];
            [dicMU setValue:[self timeConversion:[[dicMU objectForKey:@"locTime"] integerValue]] forKey:@"timeConversion"];
            //latitude
            CLLocationCoordinate2D amap = AMapCoordinateConvert(CLLocationCoordinate2DMake([[dicData objectForKey:@"latitude"] doubleValue],[[dicData objectForKey:@"longitude"] doubleValue]), AMapCoordinateTypeBaidu);
            
            [dicMU setValue:[NSString stringWithFormat:@"%f",amap.latitude] forKey:@"latitude"];
            [dicMU setValue:[NSString stringWithFormat:@"%f",amap.longitude] forKey:@"longitude"];
            
            
            [arrayMU addObject:dicMU];
        }
    }
    
    return arrayMU;
}


/**
 时间戳转化成时间

 @param locTime 时间戳
 @return 返回年月日时分秒
 */
+ (NSString *)timeConversion:(NSInteger)locTime {
    
    NSDate *confromTimesp = [NSDate dateWithTimeIntervalSince1970:locTime];
    
    NSDateFormatter *dateFormat=[[NSDateFormatter alloc]init];
    
    [dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    
    NSString* string=[dateFormat stringFromDate:confromTimesp];
    
    return string;
    
}

@end
