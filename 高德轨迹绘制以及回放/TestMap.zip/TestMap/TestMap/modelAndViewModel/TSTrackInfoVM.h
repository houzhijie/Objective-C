//
//  TSTrackInfoVM.h
//  TestMap
//
//  Created by mac on 2019/3/28.
//  Copyright © 2019 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TSHttpTool.h"

NS_ASSUME_NONNULL_BEGIN

@interface TSTrackInfoVM : NSObject

+ (void)requestTrackInfo:(requestBackData)finish;

@end

NS_ASSUME_NONNULL_END
