//
//  TSLocaModel.m
//  TestMap
//
//  Created by mac on 2019/3/28.
//  Copyright © 2019 mac. All rights reserved.
//

#import "TSLocaModel.h"

@implementation TSLocaModel

@end
