//
//  TSLocaModel.h
//  TestMap
//
//  Created by mac on 2019/3/28.
//  Copyright © 2019 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TSLocaModel : NSObject

/*
 latitude = "23.077884799552";
 locTime = 1553734039;
 longitude = "113.88459149696";
 mileage = 0;
 speed = "0.141014";
 */

@property (nonatomic , copy)NSString *latitude;
@property (nonatomic , copy)NSString *longitude;
@property (nonatomic , copy)NSString *speed;
@property (nonatomic , assign)NSInteger locTime;
@property (nonatomic , assign)NSInteger mileage;


@property (nonatomic , copy)NSString *timeConversion;  //装换后的时间  显示 年月日  时分秒
@end

NS_ASSUME_NONNULL_END
