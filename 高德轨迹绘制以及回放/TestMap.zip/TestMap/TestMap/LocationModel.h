//
//  LocationModel.h
//  TestMap
//
//  Created by houzhijie on 2019/4/30.
//  Copyright © 2019 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LocationModel : NSObject

@property (nonatomic, copy)NSString *time;
@property (nonatomic, copy)NSString *lat;
@property (nonatomic, copy)NSString *lon;
@property (nonatomic, copy)NSString *address;
@property (nonatomic, copy)NSString *citycode;

@property (nonatomic, copy)NSString *backGround;
@property (nonatomic, copy)NSString *name;

@property (nonatomic, copy)NSString *timePiece;


@end

NS_ASSUME_NONNULL_END
