//
//  TSHttpTool.h
//  TestMap
//
//  Created by mac on 2019/3/27.
//  Copyright © 2019 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^requestBackData)(id dic);

NS_ASSUME_NONNULL_BEGIN

@interface TSHttpTool : NSObject

+ (TSHttpTool *)shareHttpTool;

- (void)getActionFinishedBlock:(requestBackData)finish ;

@end

NS_ASSUME_NONNULL_END
