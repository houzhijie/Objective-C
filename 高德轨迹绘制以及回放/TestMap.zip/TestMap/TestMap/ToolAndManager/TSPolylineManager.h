//
//  TSPolylineManager.h
//  TestMap
//
//  Created by mac on 2019/3/28.
//  Copyright © 2019 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MAMapKit/MAMapKit.h>
#import <AMapFoundationKit/AMapFoundationKit.h>
#import "MATraceReplayOverlay.h"
#import "MATraceReplayOverlayRender.h"


typedef void(^blockBackValue)(NSArray *arrayColors,NSArray* indexs);

NS_ASSUME_NONNULL_BEGIN

@interface TSPolylineManager : NSObject // 画轨迹使用

@property (nonatomic, strong) MATraceReplayOverlay *overlay;
@property (nonatomic, strong) MATraceReplayOverlayRenderer *overlayRenderer;


@property (nonatomic, strong)MAMultiPolyline *texturePolyline;

@property (nonatomic, strong)MAMultiPolyline *colorFullPolyline;

// 轨迹回放annotation
@property (nonatomic, weak) MAAnimatedAnnotation *playAnnotation;

+ (TSPolylineManager *)shareManager ;

+ (void)overPlay:(MAMapView *)mapView locaPointArray:(NSArray *)arrayPoint arrayIndex:(NSArray *)arrayIndex;

- (void)polyLine:(MAMapView *)mapView locaPointArray:(NSArray *)arrayPoint arrayIndex:(NSArray *)arrayIndex;

// 获取颜色数组
+ (void)fetchColors:(NSArray *)arrayPoint block:(blockBackValue)block;

/**
 暂停
 */
- (void)stopAnimation;

/**
 开始
 */
- (void)startAnimation;

@end

NS_ASSUME_NONNULL_END
