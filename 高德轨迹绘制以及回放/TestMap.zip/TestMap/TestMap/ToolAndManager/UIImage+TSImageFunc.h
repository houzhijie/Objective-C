//
//  UIImage+TSImageFunc.h
//  TestMap
//
//  Created by mac on 2019/3/29.
//  Copyright © 2019 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (TSImageFunc)

//获取图片某一点的颜色
- (UIColor *)colorAtPixel:(CGPoint)point;

@end

NS_ASSUME_NONNULL_END
