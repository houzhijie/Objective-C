//
//  TSPolylineManager.m
//  TestMap
//
//  Created by mac on 2019/3/28.
//  Copyright © 2019 mac. All rights reserved.
//

#import "TSPolylineManager.h"
#import "TSLocaModel.h"


@interface TSPolylineManager ()

{
    BOOL isStarted;
    NSInteger _passPointAnimation;
}
@property (nonatomic, strong)MAMapView * mapView;
// 移动动画
@property (nonatomic, strong) MAAnnotationMoveAnimation *moveAnimation;

@property (nonatomic,strong)NSMutableArray * arrayModel;

@property (nonatomic,strong)NSMutableArray *animationPointArray; // 未发生动画的点

@property (nonatomic,strong)NSMutableArray *arrayColor;


@end

@implementation TSPolylineManager

static TSPolylineManager * manager;

+ (TSPolylineManager *)shareManager {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[TSPolylineManager alloc]init];
    });
    return manager;
}

+ (void)overPlay:(MAMapView *)mapView locaPointArray:(NSArray *)arrayPoint arrayIndex:(NSArray *)arrayIndex{
    [[TSPolylineManager shareManager] polyLine:mapView locaPointArray:arrayPoint arrayIndex:arrayIndex];
    [[TSPolylineManager shareManager].arrayModel addObjectsFromArray:arrayPoint];
    [TSPolylineManager shareManager].mapView = mapView;
    
    
    MAMapPoint *p = (MAMapPoint *)malloc(arrayPoint.count * sizeof(MAMapPoint));
    int index = 0;
    for(TSLocaModel *model in arrayPoint) {
        MAMapPoint point = MAMapPointForCoordinate(CLLocationCoordinate2DMake([model.latitude doubleValue], [model.longitude doubleValue]));
        
        p[index].x = point.x;
        p[index].y = point.y;
        index++;
    }
    
    TSPolylineManager * managerOver = [TSPolylineManager shareManager];
    
    managerOver.overlay = [[MATraceReplayOverlay alloc] init];
    //        self.overlay.carImage = [UIImage imageNamed:@"userPosition"];
    managerOver.overlay.enableAutoCarDirection = YES;
    managerOver.overlay.speed = 1000;
    [managerOver.overlay setWithPoints:p count:index];
    
    if(p) {
        free(p);
    }
    
    
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [managerOver.mapView addOverlay:managerOver.overlay];
        [managerOver.mapView showOverlays:@[managerOver.overlay] animated:NO];
        
        [managerOver.overlay addObserver:managerOver forKeyPath:@"isPaused" options:NSKeyValueObservingOptionOld | NSKeyValueObservingOptionNew context:NULL];
    });
    
    
}


- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context
{
    if (object == self.overlay && [keyPath isEqualToString:@"isPaused"]) {
        BOOL old = [change[NSKeyValueChangeOldKey] boolValue];
        BOOL new = [change[NSKeyValueChangeNewKey] boolValue];
        
        NSLog(@"old - %d, new - %d", old, new);
        
        self.mapView.isAllowDecreaseFrame = new;
    }
}

- (void)dealloc
{
    [self.overlay removeObserver:self forKeyPath:@"isPaused"];
}



- (void)polyLine:(MAMapView *)mapView locaPointArray:(NSArray *)arrayPoint arrayIndex:(NSArray *)arrayIndex {
    [self.arrayModel removeAllObjects];
    [self.arrayModel addObjectsFromArray:arrayPoint];
    self.mapView = mapView;
    [self.animationPointArray removeAllObjects];
    [self.animationPointArray addObjectsFromArray:arrayPoint];
    
    
    CLLocationCoordinate2D commonPolylineCoords[arrayPoint.count];
    
    for (NSInteger i = 0; i < arrayPoint.count ; i++) {
        TSLocaModel * model = arrayPoint[i];
        commonPolylineCoords[i] = CLLocationCoordinate2DMake([model.latitude doubleValue], [model.longitude doubleValue]);
        if (i == 0 || i == arrayPoint.count -1) {
            // 开始和结束点上的标注
            MAAnimatedAnnotation *anno = [[MAAnimatedAnnotation alloc] init];
            anno.coordinate = commonPolylineCoords[i];
            [mapView addAnnotation:anno];
        }
        
        
    }
    
    // 颜色折线
    MAMultiPolyline *gradientPolyline = [MAMultiPolyline polylineWithCoordinates:commonPolylineCoords count:arrayPoint.count drawStyleIndexes:arrayIndex];
    self.colorFullPolyline = gradientPolyline;
    [self.mapView addOverlay:gradientPolyline];
    
    //构造折线对象
//    MAPolyline *commonPolyline = [MAPolyline polylineWithCoordinates:commonPolylineCoords count:arrayPoint.count];
//    MAMultiPolyline * commonPolyline = [[MAMultiPolyline alloc]init];
//    [commonPolyline setPolylineWithCoordinates:commonPolylineCoords count:1 drawStyleIndexes:@[@(1)]];
//    [MAMultiPolyline polylineWithCoordinates:commonPolylineCoords count:arrayPoint.count drawStyleIndexes:arrayIndex];
    
    MAMultiPolyline *texturePolyline = [MAMultiPolyline polylineWithCoordinates:commonPolylineCoords count:arrayPoint.count drawStyleIndexes:@[@0]];
    self.texturePolyline = texturePolyline;
    [self.mapView addOverlay:texturePolyline];
    
    //在地图上添加折线对象
//    [mapView addOverlay: commonPolyline];
    
//    //
//    MAMultiPolyline *texturePolyline = [MAMultiPolyline polylineWithCoordinates:commonPolylineCoords count:arrayPoint.count drawStyleIndexes:@[@0]];
//    [TSPolylineManager shareManager].texturePolyline = texturePolyline;
//    [mapView addOverlay:texturePolyline];
    
    // 地图显示自适应
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [mapView setVisibleMapRect:texturePolyline.boundingMapRect edgePadding:UIEdgeInsetsMake(30, 50, 80, 80) animated:NO];
    });
    
}

/**
 开始
 */
- (void)startAnimation {
//    self.overlay.isPaused = !self.overlay.isPaused;
//    [self.overlayRenderer reset];
    if (isStarted == NO) {
        [self addStartMark];
        // 第一次播放

        TSLocaModel *firstModel = self.arrayModel.firstObject;
        self.playAnnotation.coordinate = CLLocationCoordinate2DMake([firstModel.latitude doubleValue], [firstModel.longitude doubleValue]);
        [self playAnimation:0];

    }

    else { // 继续播放
        [self continuePlay];
    }
    
}


// 继续播放
- (void)continuePlay
{
    
    
    // 从上次播放的点开始播放
    self.playAnnotation.coordinate = self.playAnnotation.coordinate;
    
    
    // 剩余点数(加上动画点当前位置)
    
    [self playAnimation:_passPointAnimation-1]; // _passPointAnimation 减一找到指定的点防止数组越界
}

- (void)playAnimation:(NSInteger)startLoca {
    
    NSMutableArray *arrM = [NSMutableArray array];
    for (NSInteger i = startLoca; i < self.arrayModel.count; i++) {
        CLLocationCoordinate2D coord;
        if (startLoca != 0 && isStarted == YES) {  // isStarted == YES 加这个条件是为了防止每次都进到 if里面
            coord = self.playAnnotation.coordinate;
            isStarted = NO;
        }
        else {
            TSLocaModel *model = self.arrayModel[i];
            coord =CLLocationCoordinate2DMake([model.latitude doubleValue], [model.longitude doubleValue]);
        }
        
        
        NSValue *value = [NSValue value:&coord withObjCType:@encode(CLLocationCoordinate2D)];
        [arrM addObject:value];
    }
    
    // 添加移动动画
    [self addMoveAnimatWithCoords:arrM];
}

#pragma mark - 私有
// 添加移动动画
- (void)addMoveAnimatWithCoords:(NSArray *)coords
{
    if (coords.count <= 0) return;
    
    CLLocationCoordinate2D moveCoords[coords.count];
    for (int i = 0; i < coords.count; i++) {
        id value = coords[i];
        NSValue *v = (NSValue *)value;
        [v getValue:&moveCoords[i]];
    }
    
    __weak typeof(self) weakSelf = self;
    CGFloat duration = coords.count * 0.05;
    if (coords.count > 100) {
        duration = duration > 30 ? 30 : duration;
    }

//    [self.texturePolyline setPolylineWithCoordinates:moveCoords count:coords.count];
    self.moveAnimation = [self.playAnnotation addMoveAnimationWithKeyCoordinates:moveCoords count:coords.count withDuration:duration withName:nil completeCallback:^(BOOL isFinished) {
        // 回放完成回调
//        if (weakSelf.playFinishCallBack) {
//            weakSelf.playFinishCallBack();
//        }
    } stepCallback:^(MAAnnotationMoveAnimation *currentAni) {
        // 每一帧回调,绘制轨迹,动画大头针在屏幕中间
        weakSelf.mapView.centerCoordinate = self.playAnnotation.coordinate;

        // 重新画轨迹
//        [weakSelf reDrawPolyline];
    }];
}

// 重新设置轨迹点，动态绘制轨迹
- (void)reDrawPolyline
{
    __weak typeof(self) weakSelf = self;
    NSInteger passCount = 0;
//    if (weakSelf.paused) {
//        passCount = weakSelf.passPointCount + self.moveAnimation.passedPointCount - 1;
//    }else {
//        passCount = weakSelf.moveAnimation.passedPointCount;
//    }
//
    NSMutableArray *arrM = [NSMutableArray array];
    for (int i = 0; i < passCount + 1; i++) {
        CLLocationCoordinate2D coord;
        if (i == passCount) {
            coord = weakSelf.playAnnotation.coordinate;
        }else {
            TSLocaModel *model = weakSelf.arrayModel[i];
            coord = CLLocationCoordinate2DMake([model.latitude doubleValue], [model.longitude doubleValue]);
        }
        
        NSValue *value = [NSValue value:&coord withObjCType:@encode(CLLocationCoordinate2D)];
        [arrM addObject:value];
        
    }
//    [self resetPolyline:arrM];
}


// 重新设置轨迹坐标点
//- (void)resetPolyline:(NSArray <NSValue *>*)coords
//{
//    if (!coords || coords.count == 0) return;
//
//    // 重新设置轨迹点
//    CLLocationCoordinate2D resetCoords[coords.count];
//    for (int i = 0; i < coords.count; i++) {
//        NSValue *value = coords[i];
//        [value getValue:&resetCoords[i]];
//    }
//
//    // 取颜色
//    if (coords.count == self.polylineDataArr.count) {
//        self.resetPolylineColors = self.polylineColors;
//        self.resetPolylineColorIndexs = self.polylineColorIndexs;
//    }else {
//        self.resetPolylineColors = [self.polylineColors subarrayWithRange:NSMakeRange(0, coords.count + 1)];
//        self.resetPolylineColorIndexs = [self.polylineColorIndexs subarrayWithRange:NSMakeRange(0, coords.count - 1)];
//    }
//
//    // 重新绘制多色线
//    [self.colorFullPolyline setPolylineWithCoordinates:resetCoords count:coords.count drawStyleIndexes:self.resetPolylineColorIndexs];
//
//    // 重新设置纹理线
//    [self.texturePolyline setPolylineWithCoordinates:resetCoords count:coords.count drawStyleIndexes:@[@0]];
//}

/**
 暂停
 */
- (void)stopAnimation {
    isStarted = YES;
    NSArray * arrayAnimat = self.playAnnotation.allMoveAnimations; // 只有一个对象
    MAAnnotationMoveAnimation *animation = arrayAnimat.firstObject;
    [animation cancel];
    if (animation.passedPointCount == self.arrayModel.count || animation == nil) {
        _passPointAnimation = 0;
        isStarted = NO;
    }
    else {
        _passPointAnimation = animation.passedPointCount;
        
    }
    
}

- (void)addStartMark {
    if (!self.playAnnotation) {
        TSLocaModel *model = self.arrayModel.firstObject;
        
        MAAnimatedAnnotation *anno = [[MAAnimatedAnnotation alloc] init];
        anno.coordinate = CLLocationCoordinate2DMake([model.latitude doubleValue],[ model.longitude doubleValue]);
        self.playAnnotation = anno;
        [self.mapView addAnnotation:anno];
    }
}

// 获取颜色数组
+ (void)fetchColors:(NSArray *)arrayPoint block:(blockBackValue)block
{
    // 通过速度取出不同的颜色
    NSMutableArray *colorIndex = [NSMutableArray array];
    NSMutableArray *colors = [NSMutableArray array];
    for (int i = 0; i < arrayPoint.count; i++) {
        // 分段颜色index
        if (i != 0 && i != arrayPoint.count - 1) {
            [colorIndex addObject:[NSNumber numberWithInt:i]];
        }
        
        TSLocaModel * model = arrayPoint[i];
        
        double speed = [model.speed doubleValue];
        
        // 分段颜色绘制
        UIImage *image = ImageNamed(@"test.png");
        CGPoint p = CGPointZero;
        if (speed < 5) {
            p = CGPointMake(image.size.width * 0.5, 1);
        }else if (speed > 20) {
            p = CGPointMake(image.size.width * 0.5, image.size.height - 2);
        }else {
            p = CGPointMake(image.size.width * 0.5, ((speed - 5)/15.0) * image.size.height);
        }
        
        if (p.y <= 1) p.y = 1;
        if (p.y >= image.size.height - 2) p.y = image.size.height - 2;
        
        UIColor *color = [image colorAtPixel:p];
        //        UIColor *color = [image colorWithPoint:p];
        UIColor *col = color ? color : [UIColor redColor];
        
        [colors addObject:col];
    }
    if (block) {
        block(colors,colorIndex);
    }
//    self.polylineColors = self.resetPolylineColors = colors;
//    self.polylineColorIndexs = self.resetPolylineColorIndexs = colorIndex;
}


- (NSMutableArray *)arrayModel {
    if (!_arrayModel) {
        _arrayModel = [NSMutableArray array];
    }
    return _arrayModel;
}

- (NSMutableArray *)animationPointArray {
    if (!_animationPointArray) {
        _animationPointArray = [NSMutableArray array];
    }
    return _animationPointArray;
}

- (NSMutableArray *)arrayColor {
    if (!_arrayColor) {
        _arrayColor = [NSMutableArray array];
    }
    return _arrayColor;
}

@end
