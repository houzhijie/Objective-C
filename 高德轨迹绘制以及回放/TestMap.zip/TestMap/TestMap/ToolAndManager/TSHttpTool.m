//
//  TSHttpTool.m
//  TestMap
//
//  Created by mac on 2019/3/27.
//  Copyright © 2019 mac. All rights reserved.
//

#import "TSHttpTool.h"
#import <AFNetworking/AFNetworking.h>


@interface TSHttpTool ()

@property (nonatomic,strong)AFHTTPSessionManager * manager;

@end

@implementation TSHttpTool
static TSHttpTool * httpTool;
+ (TSHttpTool *)shareHttpTool {
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        httpTool = [[TSHttpTool alloc]init];
        httpTool.manager = [AFHTTPSessionManager manager];
        httpTool.manager.requestSerializer =  [AFHTTPRequestSerializer serializer];
        httpTool.manager.requestSerializer.timeoutInterval = 15;//请求超时
        httpTool.manager.requestSerializer.cachePolicy = NSURLRequestUseProtocolCachePolicy; //缓存策略
        httpTool.manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/plain", @"text/javascript", @"text/json", @"text/html", nil];//支持类型
    });
    return httpTool;
}


- (void)getActionFinishedBlock:(requestBackData)finish {
    //   http://rdvs.deppon.com/newevs-web/locus/gettrack.do
    NSString *dateString = [self timeString];
    dateString = [dateString stringByReplacingOccurrencesOfString:@"-" withString:@""];
    NSDictionary *parameters = @{@"empCode":@"160280", @"locusDate":dateString,@"unLimit":@"0"};
    
    AFHTTPRequestSerializer *requestSerializer =  [AFJSONRequestSerializer serializer];
    NSDictionary *headerFieldValueDictionary = @{@"loginName":@"507142",@"X-RDVS-APP-CODE":@"49ae91354a2549b8b5d14ac4029ca3d3"};
    if (headerFieldValueDictionary != nil) {
        for (NSString *httpHeaderField in headerFieldValueDictionary.allKeys) {
            NSString *value = headerFieldValueDictionary[httpHeaderField];
            [requestSerializer setValue:value forHTTPHeaderField:httpHeaderField];
        }
    }
    self.manager.requestSerializer = requestSerializer;
    //http://rdvs.deppon.com/newevs-web/burying/buryingPoint.do
    [[TSHttpTool shareHttpTool].manager GET:@"http://rdvs.deppon.com/newevs-web/locus/gettrack.do" parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
//        NSJSONSerialization * jsonStr = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
        if (finish) {
            finish(responseObject);
        }
        NSLog(@"%@",responseObject);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"%@",error);
    }];
    
    
}

- (NSString *)timeString {
    //获取本地时间
    NSDate *date = [NSDate date];                            //实际上获得的是：UTC时间，协调世界时，亚州的时间与UTC的时差均为+8
    NSTimeZone *zone = [NSTimeZone systemTimeZone];                  //zone为当前时区信息  在我的程序中打印的是@"Asia/Shanghai"
    NSInteger interval = [zone secondsFromGMTForDate: date];      //28800 //所在地区时间与协调世界时差距
    NSDate *localeDate = [date dateByAddingTimeInterval: interval];  //加上时差，得到本地时间
    //get seconds since 1970
    NSTimeInterval intervalWith1970 = [localeDate timeIntervalSince1970];     //本地时间与1970年的时间差（秒数）
    int daySeconds = 24 * 60 * 60;                                            //每天秒数
    NSInteger allDays = intervalWith1970 / daySeconds;                        //这一步是为了舍去后面的时分秒
    localeDate = [NSDate dateWithTimeIntervalSince1970:allDays * daySeconds];
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    fmt.dateFormat = @"yyyy-MM-dd";
    //创建日期格式（年-月-日）
    NSString *temp = [fmt stringFromDate:localeDate];
    return temp;
}

@end
