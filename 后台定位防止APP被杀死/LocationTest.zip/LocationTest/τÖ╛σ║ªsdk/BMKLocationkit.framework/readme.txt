1、版本：
    百度地图iOS定位SDK v1.5

2、是否带IDFA：
    是

3、是否为Bitcode：
    是

4、集成方法：
    http://lbsyun.baidu.com/index.php?title=ios-locsdk
