//
//  ViewController.m
//  LocationTest
//
//  Created by houzhijie on 2019/4/18.
//  Copyright © 2019 mac. All rights reserved.
//

#import "ViewController.h"
#import "LocationCell.h"


@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong)UITableView *tableView;

@property (nonatomic,strong)NSMutableArray *arrayData;

@end

@implementation ViewController

-(void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"refreshUI" object:nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView reloadData];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshUI:) name:@"refreshUI" object:nil];
    
}

- (void)refreshUI:(NSNotification *)notifica {
    LocationModel * model = (LocationModel *)notifica.object;
    if (model!=nil) {
        [self.arrayData insertObject:model atIndex:0];
//        [self.tableView reloadData];
        [self.tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:0]] withRowAnimation:UITableViewRowAnimationFade];
//        [self.tableView setContentOffset:CGPointMake(0, CGFLOAT_MAX)];
//        [self.tableView reloadData];
    }
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.arrayData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    LocationCell * cell = [tableView dequeueReusableCellWithIdentifier:@"LocationCell"];
    cell.model = self.arrayData[indexPath.row];
    return cell;
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStylePlain];
        
        _tableView.delegate = self;
        _tableView.dataSource = self;
        
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        _tableView.estimatedRowHeight = 100;
        _tableView.rowHeight = UITableViewAutomaticDimension;
        
        [_tableView registerNib:[UINib nibWithNibName:@"LocationCell" bundle:nil] forCellReuseIdentifier:@"LocationCell"];
        
        [self.view addSubview:_tableView];
    }
    return _tableView;
}

- (NSMutableArray *)arrayData {
    if (!_arrayData) {
        _arrayData = [NSMutableArray array];
    }
    return _arrayData;
}

@end
