//
//  LocationModel.m
//  LocationTest
//
//  Created by houzhijie on 2019/4/24.
//  Copyright © 2019 mac. All rights reserved.
//

#import "LocationModel.h"
#import "SaveLocationTool.h"


@implementation LocationModel

- (void)modelTimePiece {
    NSDate *datenow = [NSDate date];//现在时间
    
    //时间转时间戳的方法:
    NSInteger now = [[NSNumber numberWithDouble:[datenow timeIntervalSince1970]] integerValue];
    NSInteger lastModelTime = 0;
    if ([[SaveLocationTool shareLocationTool] isExistTable:@"LocationModel"]) {
        LocationModel * model = [[SaveLocationTool shareLocationTool] lastDataWithTableName:@"LocationModel"];
        lastModelTime = [self timeSwitchTimestamp:model.time andFormatter:nil];
        if (lastModelTime == 0) {
            self.timePiece = @"0";
        }
        
        self.timePiece = [NSString stringWithFormat:@"%ld",now-lastModelTime];
    }
    else{
        self.timePiece = @"还没有存入数据";
    }
}

- (NSString *)timePiece {
    if ([_timePiece isEqualToString:@"打开APP第一次计数"] || [_timePiece isEqualToString:@"还没有存入数据"]) {
        return _timePiece;
    }
    return [NSString stringWithFormat:@"%@秒",_timePiece];
}


- (NSInteger)timeSwitchTimestamp:(NSString *)formatTime andFormatter:(NSString *)format{
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    
    [formatter setDateFormat:@"yyyy-MM-dd hh:mm:ss"]; //(@"YYYY-MM-dd hh:mm:ss") ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Beijing"];
    
    [formatter setTimeZone:timeZone];
    NSDate* date = [formatter dateFromString:formatTime]; //------------将字符串按formatter转成nsdate
    
    //时间转时间戳的方法:
    
    NSInteger timeSp = [[NSNumber numberWithDouble:[date timeIntervalSince1970]] integerValue];
    return timeSp;
}


@end
