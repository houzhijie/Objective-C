//
//  SaveLocationTool.m
//  LocationTest
//
//  Created by houzhijie on 2019/4/24.
//  Copyright © 2019 mac. All rights reserved.
//

#import "SaveLocationTool.h"
#import "JQFMDB.h"

@implementation SaveLocationTool

static SaveLocationTool * tool;
+ (instancetype)shareLocationTool {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        tool = [[SaveLocationTool alloc]init];
    });
    return tool;
}



#pragma mark -- 操作数据库


/**
 查看所有的数据
 
 @param tableName 要查看的表的名字
 @return 返回
 */
-(NSArray *)lookDataTableName:(NSString *)tableName{
    JQFMDB *db = [JQFMDB shareDatabase];
    NSArray *personArr = [db jq_lookupTable:tableName dicOrModel:[NSClassFromString(tableName) class] whereFormat:nil]; // 如果要做成多人的本地数据  可以存用户的id  来区分数据的归属 [NSString stringWithFormat:@"where userId = '%@'",[[LocalDataTool shareLocalDataTool]getUserID]]
    
    return personArr;
}

/**
 查看具体一条数据
 
 @param tableName 要查看的表的名字
 @param format 条件 写法 "where 属性 = '%@'" 如 "where vid = '%@'"
 @return 返回 modle 或者是nil
 */
-(id)lookDataModelWithTableName:(NSString *)tableName
                         format:(NSString *)format{
    JQFMDB *db = [JQFMDB shareDatabase];
    NSArray *personArr = [db jq_lookupTable:tableName dicOrModel:[NSClassFromString(tableName) class] whereFormat:format]; // 如果要做成多人的本地数据  可以存用户的id  来区分数据的归属 [NSString stringWithFormat:@"where userId = '%@'",[[LocalDataTool shareLocalDataTool]getUserID]]
    return (personArr != nil)? [personArr firstObject]:nil ;
}

/**
 查看数据是否存在
 
 @param tableName 表名字
 @param format 条件 写法 "where 属性 = '%@'" 如 "where vid = '%@'"
 @return 返回结果 yes 存在 NO 不存在
 */
-(BOOL)isExistTableName:(NSString *)tableName
                 format:(NSString *)format{
    JQFMDB *db = [JQFMDB shareDatabase];
    
    NSArray *personArr = [db jq_lookupTable:tableName dicOrModel:[NSClassFromString(tableName) class] whereFormat:format];
    BOOL isExist = NO;
    if (personArr.count != 0) {
        isExist = YES;
    }
    return isExist;
}



/**
 查询表是否存在

 @param tableName 表名
 @return return value description
 */
-(BOOL)isExistTable:(NSString *)tableName {
    JQFMDB *db = [JQFMDB shareDatabase];
    return [db jq_isExistTable:tableName];
}

/**
 删除表中的数据
 
 @param tableName 表名字
 @param format 条件 写法 "where 属性 = '%@'" 如 "where vid = '%@'"
 */
-(BOOL)deleteDataTableName:(NSString *)tableName
                    format:(NSString *)format{
    JQFMDB *db = [JQFMDB shareDatabase];
    return  [db jq_deleteTable:tableName whereFormat:format];
}


/**
 更改model
 
 @param tableName 表名
 @param model model
 @param format 条件 写法 "where 属性 = '%@'" 如 "where vid = '%@'"
 */
-(void)updateDataWithTableName:(NSString *)tableName
                         model:(id)model
                        format:(NSString *)format{
    JQFMDB *db = [JQFMDB shareDatabase];
    [db jq_updateTable:tableName dicOrModel:model whereFormat:format];
}

/**
 存储model
 
 @param tableName 表名
 @param historyModel model
 */
-(void)saveDataTableName:(NSString *)tableName historyModel:(id)historyModel {
    [[SaveLocationTool shareLocationTool] createTableDBTableName:tableName];
    
    JQFMDB *db = [JQFMDB shareDatabase];
    
    if ([db jq_insertTable:tableName dicOrModel:historyModel]) {
        NSLog(@"model存储成功");
    }
    
}

/**
 创建表
 
 @param tableName model的类名
 */
-(void)createTableDBTableName:(NSString *)tableName{
    JQFMDB *db = [JQFMDB shareDatabase];
    if (![db jq_isExistTable:tableName]) {
        [db jq_createTable:tableName dicOrModel:[NSClassFromString(tableName) class]];
    }
}


/**
 删除表
 
 @param tableName 表名
 @return 返回删除结果 yes 为成功 no 为失败
 */
-(BOOL)deleteTableName:(NSString *)tableName{ //signOut
    JQFMDB *db = [JQFMDB shareDatabase];
    return  [db jq_deleteTable:tableName];
}


/**
 查询表中最后一条数据

 @param tableName 表名
 @return return value description
 */
- (id)lastDataWithTableName:(NSString *)tableName{
    JQFMDB *db = [JQFMDB shareDatabase];
    NSInteger lastPkid = [db lastInsertPrimaryKeyId:tableName];
    NSArray * array = [db jq_lookupTable:tableName dicOrModel:[NSClassFromString(tableName) class] whereFormat:[NSString stringWithFormat:@"where pkid = '%ld'",lastPkid]];
    return [array lastObject];
}

@end
