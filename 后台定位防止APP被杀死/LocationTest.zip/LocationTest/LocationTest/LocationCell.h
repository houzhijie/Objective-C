//
//  LocationCell.h
//  LocationTest
//
//  Created by houzhijie on 2019/4/24.
//  Copyright © 2019 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LocationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LocationCell : UITableViewCell
@property (nonatomic,strong)LocationModel *model;

@end

NS_ASSUME_NONNULL_END
