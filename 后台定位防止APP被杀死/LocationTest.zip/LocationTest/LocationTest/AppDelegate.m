//
//  AppDelegate.m
//  LocationTest
//
//  Created by houzhijie on 2019/4/18.
//  Copyright © 2019 mac. All rights reserved.
//

#import "AppDelegate.h"


// 系统定位
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

// 高德
#import <AMapFoundationKit/AMapFoundationKit.h>
#import <AMapLocationKit/AMapLocationKit.h>

// 百度
#import <BMKLocationkit/BMKLocationComponent.h>



#import "LocationModel.h"

#import "ViewController.h"

#import "SaveLocationTool.h"



@interface AppDelegate ()<CLLocationManagerDelegate,AMapLocationManagerDelegate,BMKLocationManagerDelegate,BMKLocationAuthDelegate>

{
    NSString *_backGround;
    UIColor * _color;
    BOOL _isNewProgram;
    
    
    NSString *_lat;
    NSString *_lon;
}

@property (nonatomic , strong)NSTimer * timer;
 @property (nonatomic, assign) UIBackgroundTaskIdentifier bgTask;
@property (nonatomic, assign) NSInteger backgroundTime;

@property (nonatomic, strong) AMapLocationManager *locationManager;
@property (nonatomic, strong) BMKLocationManager *baiduLocationManager;

@property (nonatomic ,strong) CLLocationManager *manager;

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    // 高德
//    [AMapServices sharedServices].apiKey =@"0d256ace1bbd3b89106d4b2f1953420f";
//    [self initGaoDeLocationManager];
//
    
//    要想使用GPS位置将下面注释打开  将上面代码注释掉
//    [self initLocationManager];
    _isNewProgram = YES;
    [[BMKLocationAuth sharedInstance] checkPermisionWithKey:@"vpdyFbZmefZVr2vILwvRCfZiP9I7bPbu" authDelegate:self];
    [self initBaiduLocationManager];
    
    self.backgroundTime = 0;
    _color = [UIColor blueColor];
    _backGround = @"手机前台";
    return YES;
}



- (void)initBaiduLocationManager {
    if (!_baiduLocationManager) {
        //初始化实例
        _baiduLocationManager = [[BMKLocationManager alloc] init];
    }
    

    //设置delegate
    _baiduLocationManager.delegate = self;
    //设置返回位置的坐标系类型
    _baiduLocationManager.coordinateType = BMKLocationCoordinateTypeBMK09LL;
    //设置距离过滤参数
    _baiduLocationManager.distanceFilter = 10;
    //设置预期精度参数
    _baiduLocationManager.desiredAccuracy = kCLLocationAccuracyBest;
    //设置应用位置类型
    _baiduLocationManager.activityType = CLActivityTypeFitness;
    //设置是否自动停止位置更新
    _baiduLocationManager.pausesLocationUpdatesAutomatically = NO;
    //设置是否允许后台定位
    _baiduLocationManager.allowsBackgroundLocationUpdates = YES;
    //设置位置获取超时时间
    _baiduLocationManager.locationTimeout = 10;
    //设置获取地址信息超时时间
    _baiduLocationManager.reGeocodeTimeout = 10;
    
    [_baiduLocationManager setLocatingWithReGeocode:YES];
    [_baiduLocationManager startUpdatingLocation];
    
}

/**
 初始化高德AMapLocationManager对象
 */
- (void)initGaoDeLocationManager {
    if (!self.locationManager) {
        self.locationManager = [[AMapLocationManager alloc] init];
    }
    
    self.locationManager.delegate = self;
    
    self.locationManager.distanceFilter = kCLDistanceFilterNone;
//    [self.locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
    [self.locationManager setDesiredAccuracy:5];
    //iOS 9（不包含iOS 9） 之前设置允许后台定位参数，保持不会被系统挂起
    [self.locationManager setPausesLocationUpdatesAutomatically:NO];
    
    self.locationManager.locatingWithReGeocode = YES;
    //iOS 9（包含iOS 9）之后新特性：将允许出现这种场景，同一app中多个locationmanager：一些只能在前台定位，另一些可在后台定位，并可随时禁止其后台定位。
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 9) {
        self.locationManager.allowsBackgroundLocationUpdates = YES;
    }
    self.locationManager.locationTimeout = 10;
    self.locationManager.reGeocodeTimeout = 10;
    //开始持续定位
    [self.locationManager startUpdatingLocation];
    [self.locationManager startUpdatingHeading];
}

/**
 初始化系统CLLocationManager对象
 */
-(void)initLocationManager{
    if (!_manager) {
        //1.创建定位管理对象
        _manager = [[CLLocationManager alloc] init];
    }
    
    
    //2.设置属性 distanceFilter、desiredAccuracy
    _manager.distanceFilter = kCLDistanceFilterNone;//实时更新定位位置
    _manager.desiredAccuracy = kCLLocationAccuracyBest;//定位精确度
    if([_manager respondsToSelector:@selector(requestAlwaysAuthorization)]){
        [_manager requestAlwaysAuthorization];
    }
    //该模式是抵抗程序在后台被杀，申明不能够被暂停
    _manager.pausesLocationUpdatesAutomatically = NO;
    _manager.allowsBackgroundLocationUpdates = YES;

    _manager.delegate = self;
    //4.开始定位
    [_manager startUpdatingLocation];
    //5.获取朝向
    [_manager startUpdatingHeading];
}
#pragma mark -- 百度返回授权验证错误
- (void)onCheckPermissionState:(BMKLocationAuthErrorCode)iError {
    NSLog(@"百度鉴权错误码: %ld",(long)iError);
}

#pragma mark -- 百度定位位置更新
- (void)BMKLocationManager:(BMKLocationManager * _Nonnull)manager didUpdateLocation:(BMKLocation * _Nullable)location orError:(NSError * _Nullable)error

{
    LocationModel * modle = [[LocationModel alloc]init];
    [modle modelTimePiece];
    [self locationModel:modle];
    
    
    modle.textColor = _color;
    modle.backGround = _backGround;
    if (_isNewProgram) { // 程序被杀死后等很长时间打开  第一次时间间隔为0
        modle.timePiece = @"打开APP第一次计数";
        _isNewProgram = NO;
    }
    
    if (location) {//得到定位信息，添加annotation
        if (location.location) {
            CLLocation *newLocation=location.location;
            modle.lat = [NSString stringWithFormat:@"%f",newLocation.coordinate.latitude];
            modle.lon = [NSString stringWithFormat:@"%f",newLocation.coordinate.longitude];
            NSLog(@"%@,%@",modle.lat,modle.lon);
            _lat = modle.lat;
            _lon = modle.lon;
        }
        if (location.rgcData) {
            NSLog(@"%@",[location.rgcData description]);
            NSLog(@"%@",location.rgcData.locationDescribe);
            NSString * address = [NSString stringWithFormat:@"%@%@%@%@%@",location.rgcData.province,location.rgcData.city,location.rgcData.district,location.rgcData.street,location.rgcData.locationDescribe];
            NSLog(@"%@",address);
            modle.address = address;
        }
    }
    if (error)
    {
         modle.address = [NSString stringWithFormat:@"定位错误信息:{%ld - %@};", (long)error.code, error.localizedDescription];
    }
    
//    NSLog(@"时间间隔:-----------------%@",modle.timePiece);
    [[SaveLocationTool shareLocationTool] saveDataTableName:@"LocationModel" historyModel:modle];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"refreshUI" object:modle];
    
}


/**
 * @brief 该方法为BMKLocationManager提供设备朝向的回调方法。
 * @param manager 提供该定位结果的BMKLocationManager类的实例
 * @param heading 设备的朝向结果
 */
- (void)BMKLocationManager:(BMKLocationManager * _Nonnull)manager
          didUpdateHeading:(CLHeading * _Nullable)heading{
    
}


#pragma mark --- 系统定位成功调用此方法
//定位成功调用的的方法
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations{
    
    // 获取位置信息  是GPS的 对应的坐标
    CLLocation *newLocation=[locations lastObject];
    double lat = newLocation.coordinate.latitude;
    double lon = newLocation.coordinate.longitude;
    double alt = newLocation.altitude;
    NSLog(@"纬度:%f,经度:%f,海拔:%f",lat,lon,alt);
}

#pragma mark -- 高德位置权限访问
/**
 要在此函数内 加上 [locationManager requestAlwaysAuthorization];  申请权限

 @param manager AMapLocationManager
 @param locationManager CLLocationManager
 */
- (void)amapLocationManager:(AMapLocationManager *)manager doRequireLocationAuth:(CLLocationManager*)locationManager {
    [locationManager requestAlwaysAuthorization];
}

#pragma mark --- 高德位置更新
/**
 高德定位成功调用此方法

 @param manager manager
 @param location 当前位置
 @param reGeocode 逆地理位置  就是当前的省市区街道...
 */
- (void)amapLocationManager:(AMapLocationManager *)manager didUpdateLocation:(CLLocation *)location reGeocode:(AMapLocationReGeocode *)reGeocode
{
    LocationModel * modle = [[LocationModel alloc]init];
    [self locationModel:modle];
    modle.lat = [NSString stringWithFormat:@"%f",location.coordinate.latitude];
    modle.lon = [NSString stringWithFormat:@"%f",location.coordinate.longitude];
    
    //AMapLocationReGeocode:{formattedAddress:上海市青浦区徐祥路e通世界南区; country:中国;province:上海市; city:上海市; district:青浦区; citycode:021; adcode:310118; street:徐祥路; number:304; POIName:e通世界南区; AOIName:(null);}
    
    modle.textColor = _color;
    modle.backGround = _backGround;
    NSLog(@"location:{lat:%f; lon:%f; accuracy:%f}", location.coordinate.latitude, location.coordinate.longitude, location.horizontalAccuracy);
    if (reGeocode)
    {
        NSLog(@"reGeocode:%@", reGeocode);
        
        modle.address = reGeocode.formattedAddress;
    }
    else {
        modle.address = @"解析位置中...";
    }
    [[SaveLocationTool shareLocationTool] saveDataTableName:@"LocationModel" historyModel:modle]; // 将数据存到本地数据库
    [[NSNotificationCenter defaultCenter] postNotificationName:@"refreshUI" object:modle];
}

- (void)locationModel:(LocationModel *)model {
    NSDate *date=[NSDate date];
    NSDateFormatter *format1=[[NSDateFormatter alloc] init];
    [format1 setDateFormat:@"yyyy-MM-dd hh:mm:ss"];
    NSString *dateStr;
    dateStr=[format1 stringFromDate:date];
    model.time = dateStr;
    
}

/**
 此时APP将要加入挂起状态

 @param application application
 */
- (void)applicationWillResignActive:(UIApplication *)application {
    //允许应用程序接收远程控制
    [[UIApplication sharedApplication] beginReceivingRemoteControlEvents];
    [self.baiduLocationManager startUpdatingLocation];// 百度开始刷新位置
    
//    [self.locationManager startUpdatingLocation]; // 高德开始刷新位置
//    [self.manager startUpdatingLocation]; //系统开始刷新位置
    
}


/**
 后台状态

 @param application application
 */
- (void)applicationDidEnterBackground:(UIApplication *)application {
    
    NSLog(@"进入后台");
    UIApplication *app = [UIApplication sharedApplication];
    __block  UIBackgroundTaskIdentifier bgTask;
    bgTask = [app beginBackgroundTaskWithExpirationHandler:^{
        dispatch_async(dispatch_get_main_queue(), ^{
            
            if (bgTask != UIBackgroundTaskInvalid){
                bgTask = UIBackgroundTaskInvalid;
            }
        });
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            if (bgTask != UIBackgroundTaskInvalid){
                bgTask = UIBackgroundTaskInvalid;
            }
        });
    });
    _color = [UIColor redColor];
    _backGround = @"手机后台";
    [self.baiduLocationManager startUpdatingLocation]; // 百度开始刷新位置
//    [self.locationManager startUpdatingLocation];// 高德开始刷新位置
//    [self.manager startUpdatingLocation]; //系统开始刷新位置
    
    //开启定时器 不断向系统请求后台任务执行的时间
    if (!self.timer) {
        self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(applyForMoreTime) userInfo:nil repeats:YES];
    }

    [self.timer fire];
    
}

-(void)applyForMoreTime {
    self.backgroundTime++;
    NSLog(@"测试%ld",self.backgroundTime);
//    if (self.backgroundTime%60 == 0) {
//        [self.locationManager requestLocationWithReGeocode:YES completionBlock:^(CLLocation *location, AMapLocationReGeocode *regeocode, NSError *error) {
//
//            if (error)
//            {
//                NSLog(@"locError:{%ld - %@};", (long)error.code, error.localizedDescription);
//
//                if (error.code == AMapLocationErrorLocateFailed)
//                {
//                    return;
//                }
//            }
//
//            NSLog(@"location:%@", location);
//
//            if (regeocode)
//            {
//                NSLog(@"reGeocode:%@", regeocode);
//            }
//        }];
//    }
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    
    _color = [UIColor blueColor];
    _backGround = @"手机前台";
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    NSLog(@"22222222222");
}


- (void)applicationWillTerminate:(UIApplication *)application {
    NSLog(@"333333333333");
    LocationModel * modle = [[LocationModel alloc]init];
    modle.lon = _lon;
    modle.lat = _lat;
    modle.address = @"程序被杀死";
    [[SaveLocationTool shareLocationTool] saveDataTableName:@"LocationModel" historyModel:modle];
}


@end
