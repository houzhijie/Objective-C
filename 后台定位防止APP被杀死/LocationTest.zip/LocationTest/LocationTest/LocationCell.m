//
//  LocationCell.m
//  LocationTest
//
//  Created by houzhijie on 2019/4/24.
//  Copyright © 2019 mac. All rights reserved.
//

#import "LocationCell.h"

@interface LocationCell ()

@property (weak, nonatomic) IBOutlet UILabel *time;
@property (weak, nonatomic) IBOutlet UILabel *latAndLon;
@property (weak, nonatomic) IBOutlet UILabel *address;
@property (weak, nonatomic) IBOutlet UILabel *timePiece;

@end

@implementation LocationCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}


- (void)setModel:(LocationModel *)model {
    _model = model;
    self.time.text = [NSString stringWithFormat:@"时间:%@",model.time];
    self.latAndLon.text = [NSString stringWithFormat:@"经纬度:%@,%@",model.lat,model.lon];
    self.timePiece.text = [NSString stringWithFormat:@"时间间隔:%@",model.timePiece];
    
    self.address.text = model.address;
    self.time.textColor = model.textColor;
    self.latAndLon.textColor = model.textColor;
    self.address.textColor = model.textColor;
    self.timePiece.textColor = model.textColor;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
