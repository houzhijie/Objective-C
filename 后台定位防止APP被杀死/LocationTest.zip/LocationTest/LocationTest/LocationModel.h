//
//  LocationModel.h
//  LocationTest
//
//  Created by houzhijie on 2019/4/24.
//  Copyright © 2019 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LocationModel : NSObject

@property (nonatomic, copy)NSString *time;
@property (nonatomic, copy)NSString *lat;
@property (nonatomic, copy)NSString *lon;
@property (nonatomic, copy)NSString *address;
@property (nonatomic, copy)NSString *citycode;
@property (nonatomic, strong)UIColor *textColor;
@property (nonatomic, copy)NSString *backGround;
@property (nonatomic, copy)NSString *name;

@property (nonatomic, copy)NSString *timePiece;


- (void)modelTimePiece;

@end

NS_ASSUME_NONNULL_END
